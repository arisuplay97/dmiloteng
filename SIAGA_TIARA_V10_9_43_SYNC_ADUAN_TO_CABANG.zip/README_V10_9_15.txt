SIAGA TIARA V10.9.15 - RIWAYAT TANPA KETIK

Update:
1. Riwayat Aduan tidak lagi menampilkan instruksi:
   - Balas nomor pilihan
   - Balas menu untuk kembali
2. Riwayat Aduan sekarang dikirim sebagai WhatsApp List Menu dengan tombol:
   - Pilih Tiket
3. Pelanggan tinggal pilih tiket dari list, tidak perlu mengetik angka.
4. Di dalam list Riwayat juga ada pilihan:
   - Menu Utama
5. Jika nomor belum punya aduan, sistem menampilkan tombol:
   - Buat Aduan
   - Cek Status
   - Menu Utama
6. Tetap membawa update V10.9.14:
   - Cek Tiket Ini
   - Kalimat khusus Ditunda
   - Validasi No Pelanggan
7. Tetap membawa update V10.9.13 dan patch performance V10.9.12.

Catatan:
- WhatsApp List Menu umumnya dibatasi 10 baris, jadi sistem menampilkan maksimal 9 tiket terbaru + 1 Menu Utama.
- Jika API provider gagal mengirim list menu, sistem fallback ke teks ringkas.
