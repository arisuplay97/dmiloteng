SIAGA TIARA V10.9.34 - REPEAT HOURS CONFIG

Update:
1. Jeda tampil ulang pengumuman sekarang cukup ganti angka di CONFIG.
2. Cari bagian ini di Code.gs:

   PENGUMUMAN_REPEAT_HOURS: 6,

3. Contoh:
   - 1  = pengumuman tampil maksimal 1x per nomor per 1 jam
   - 6  = 1x per nomor per 6 jam
   - 12 = 1x per nomor per 12 jam
   - 24 = 1x per nomor per 24 jam
   - 0  = tampil setiap kali pelanggan membuka Menu Utama

4. Tidak perlu hitung detik lagi.
5. Semua update V10.9.33 ke bawah tetap dibawa.
