SIAGA TIARA V10.9.24 - INFO LAYANAN DETAIL

Update:
1. Menu utama nomor 4 diperluas menjadi "Info Layanan & Pembayaran".
2. Menu Info Layanan dikirim sebagai List Menu WhatsApp dengan pilihan:
   - Cara Bayar
   - Kendala Bayar
   - Air Tangki
   - Balik Nama
   - Pindah Meter Air
   - Sambung Kembali
   - Sambungan Pemindahan Meter Air
   - Menu Utama
3. Detail yang ditambahkan hanya berdasarkan data yang diberikan user:
   - Air Tangki
   - Balik Nama
   - Pindah Meter Air
   - Sambung Kembali
   - Sambungan Pemindahan Meter Air
4. Item yang belum ada datanya, seperti Struktur Tarif dan Formulir Sambungan Baru, belum diisi.
5. Setiap detail layanan memiliki tombol:
   - Kembali
   - Menu Utama
6. Kendala Bayar memiliki tombol:
   - Hubungi Admin
   - Kembali
   - Menu Utama
7. Semua update V10.9.23 ke bawah tetap dibawa.
