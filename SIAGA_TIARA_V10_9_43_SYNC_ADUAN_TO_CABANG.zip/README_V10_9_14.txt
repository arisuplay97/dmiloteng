SIAGA TIARA V10.9.14 - CEK TIKET, DITUNDA, VALIDASI NO PELANGGAN

Update:
1. Setelah aduan berhasil dibuat, tombol berubah menjadi:
   - Cek Tiket Ini
   - Riwayat Aduan
   - Menu Utama

2. Tombol "Cek Tiket Ini" langsung mengecek status tiket yang baru dibuat tanpa pelanggan mengetik ID.

3. Status "Ditunda" punya kalimat khusus:
   - Penanganan ditunda sementara karena perlu pengecekan/koordinasi lanjutan.
   - Aduan tetap tercatat dan akan dilanjutkan kembali.

4. Validasi No Pelanggan diperketat:
   - Hanya angka, spasi, dan tanda strip.
   - Minimal 5 digit.
   - Maksimal 20 digit.
   - Input seperti "abc123", "tidak tahu", "belum ada", "-", atau "123" akan ditolak.
   - Format seperti "01 020 304 05" dan "01-020-304-05" diterima lalu disimpan menjadi angka bersih.

Catatan:
- Tetap membawa update V10.9.13: tombol Batal/Kembali di proses input.
- Tetap membawa patch performance V10.9.12.
