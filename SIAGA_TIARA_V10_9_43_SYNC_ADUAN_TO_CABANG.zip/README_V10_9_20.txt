SIAGA TIARA V10.9.20 - MENU UTAMA LUAR JAM

Update:
1. Tombol Menu Utama dikembalikan pada mode luar jam kerja.
2. Saat Menu Utama ditekan di luar jam kerja, sistem tetap menampilkan menu terbatas:
   - Cek Status
   - Riwayat Aduan
   - Menu Utama
3. Menu Utama tidak membuka layanan penuh di luar jam kerja.
4. Pesan luar jam diberi keterangan bahwa Menu Utama tetap menu terbatas sampai jam kerja aktif kembali.
5. Semua update V10.9.19 ke bawah tetap dibawa.

Alasan:
- Tombol Menu Utama memang cocok sebagai tombol kembali.
- Yang penting, di luar jam kerja tombol itu tidak membuka Buat Aduan Baru / Hubungi Admin.
