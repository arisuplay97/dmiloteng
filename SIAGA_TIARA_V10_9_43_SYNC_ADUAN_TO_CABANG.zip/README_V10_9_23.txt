SIAGA TIARA V10.9.23 - GREETING SAHABAT TIARA

Update:
1. Kalimat menu utama WhatsApp diperbarui menjadi:

Hallo Sahabat Tiara, Selamat datang di layanan WhatsApp *PERUMDAM Tirta Ardhia Rinjani Kabupaten Lombok Tengah*.

Saya adalah *SIAGA TIARA*, layanan informasi aduan gangguan air.

Silakan pilih layanan yang Anda butuhkan.

2. Update diterapkan pada menu utama teks dan body interactive list menu jika ditemukan.
3. Semua update V10.9.22 ke bawah tetap dibawa.

Jumlah penggantian greeting teks: 3
Jumlah penggantian greeting interactive: 0
