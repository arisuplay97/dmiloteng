SIAGA TIARA V10.9.30 - MENU UTAMA FULL LIST

Perbaikan sesuai arahan:
1. Tombol Menu Utama sekarang kembali membuka menu utama berbentuk List Menu seperti sebelumnya.
2. Menu Utama tidak lagi menampilkan menu terbatas teks saat luar jam kerja.
3. List Menu Utama tetap berisi:
   - Buat Aduan Baru
   - Cek Status Aduan
   - Riwayat Aduan
   - Info Layanan
4. Jika pelanggan memilih Buat Aduan Baru atau Hubungi Admin/layanan yang dibatasi di luar jam kerja, sistem tetap menolak sesuai aturan jam kerja.
5. Tombol Menu Utama dikembalikan pada nav luar jam kerja agar bisa dipakai sebagai tombol kembali.
6. Semua update V10.9.29 ke bawah tetap dibawa.

Catatan:
- Setelah deploy, gunakan tombol/pesan baru. Tombol lama yang sudah telanjur ada di chat WhatsApp masih membawa format lama.
