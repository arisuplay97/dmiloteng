SIAGA TIARA V10.9.13 - INPUT CONTROL BUTTONS

Update:
1. Menghapus kalimat:
   "Setelah ini sistem langsung meminta No Pelanggan, bukan desa/dusun lagi."
2. Menghapus instruksi "Ketik batal".
3. Menambahkan tombol pada proses input aduan:
   - Batal
   - Kembali
4. Tombol Batal membatalkan proses dan menampilkan tombol menu utama.
5. Tombol Kembali membawa pelanggan ke langkah sebelumnya:
   - Dari nama pelanggan kembali ke pilih cabang
   - Dari No Pelanggan kembali ke nama pelanggan
   - Dari jenis kembali ke No Pelanggan
   - Dari keterangan kembali ke jenis
   - Dari lokasi kembali ke keterangan
6. Tetap membawa patch performance V10.9.12.
