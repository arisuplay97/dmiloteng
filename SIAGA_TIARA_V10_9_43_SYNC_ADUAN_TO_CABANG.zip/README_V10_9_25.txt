SIAGA TIARA V10.9.25 - FIX MENU UTAMA LUAR JAM

Masalah:
- Di menu terbatas luar jam kerja, tombol "Menu Utama" hanya mengulang menu yang sama.
- Akibatnya terlihat seperti tombol belum berfungsi/loop.
- Selain itu, teks menu luar jam menampilkan 3 layanan:
  1. Cek Status
  2. Riwayat Aduan
  3. Info Layanan & Pembayaran
  tetapi tombol yang muncul sebelumnya hanya Cek Status, Riwayat, dan Menu Utama.

Perbaikan:
1. Tombol luar jam sekarang menjadi:
   - Cek Status
   - Riwayat Aduan
   - Info Layanan
2. Tombol Menu Utama tidak ditampilkan pada menu terbatas itu sendiri karena redundant.
3. Tombol Menu Utama tetap dipakai di halaman detail/status sebagai tombol kembali ke menu.
4. Kalimat "Menu Utama akan tetap menampilkan menu terbatas..." dihapus agar tidak membingungkan.
5. Semua update V10.9.24 ke bawah tetap dibawa.

Yang perlu dites:
- Di luar jam kerja tekan Menu Utama dari halaman detail/status: muncul menu terbatas.
- Di menu terbatas, tombol yang muncul harus Cek Status, Riwayat Aduan, Info Layanan.
- Klik Info Layanan: harus membuka list Info Layanan & Pembayaran.
