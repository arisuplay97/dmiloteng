SIAGA TIARA V10.9.37 - ARSIP RIWAYAT HP

Update:
1. Ditambahkan menu:
   Arsip > Arsipkan Semua Selesai/Batal

   Fungsinya memindahkan SEMUA tiket final status Selesai/Batal dari sheet ADUAN ke sheet ARSIP_YYYY_MM,
   tanpa batas bulan. Setelah dipindahkan, tiket tidak muncul lagi di Riwayat Aduan WhatsApp.

2. Ditambahkan menu:
   Arsip > Arsipkan Selesai/Batal per No WA

   Fungsinya memindahkan tiket final status Selesai/Batal khusus untuk satu nomor WhatsApp pelanggan.
   Cocok kalau ingin Riwayat Aduan pelanggan tersebut menjadi kosong jika semua tiketnya sudah selesai/batal.

3. Status yang diarsipkan:
   - Selesai
   - Batal

4. Status yang tetap di ADUAN:
   - Baru
   - Proses
   - Ditunda
   - status lain yang belum final

5. Sistem tetap membuat backup otomatis:
   BACKUP_ADUAN_YYYYMMDD_HHMMSS

6. Data arsip tetap dipisah berdasarkan bulan Waktu Masuk:
   ARSIP_2026_05, ARSIP_2026_06, dst.

Catatan penting:
- Riwayat Aduan di HP membaca data dari sheet ADUAN.
- Jadi kalau tiket Selesai/Batal diarsipkan, tiket itu hilang dari Riwayat HP.
- Kalau pelanggan masih punya tiket Baru/Proses/Ditunda, Riwayat HP tetap muncul karena itu masih aktif.

Semua update V10.9.36 ke bawah tetap dibawa.
