SIAGA TIARA V10.9.26 - MENU UTAMA TETAP ADA

Update:
1. Tombol Menu Utama dikembalikan lagi pada mode luar jam kerja.
2. Tombol luar jam kerja sekarang:
   - Cek Status
   - Riwayat Aduan
   - Menu Utama
3. Saat Menu Utama ditekan di luar jam kerja, sistem tetap membuka menu terbatas luar jam kerja, bukan menu penuh.
4. Teks luar jam kerja disesuaikan agar tidak menampilkan pilihan yang tidak punya tombol.
5. Semua update V10.9.25 ke bawah tetap dibawa.

Catatan:
- Karena tombol WhatsApp maksimal 3, tombol Info Layanan tidak ditaruh di quick button luar jam kerja.
- Info Layanan & Pembayaran tetap tersedia dari menu utama/interaktif pada jam kerja dan tetap ada di kode.
