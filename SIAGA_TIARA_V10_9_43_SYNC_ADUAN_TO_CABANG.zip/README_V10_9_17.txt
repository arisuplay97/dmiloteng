SIAGA TIARA V10.9.17 - FIX TOMBOL SETELAH BATAL

Masalah:
- Setelah pelanggan menekan tombol Batal, session dikosongkan.
- Tombol Buat Aduan / Cek Status / Riwayat Aduan tetap mengirim pilihan menu 1/2/3.
- Di versi sebelumnya, saat session kosong, angka 1/2 tidak diproses sebagai pilihan menu.
- Akibatnya tombol Cek Status setelah Batal bisa terasa tidak berfungsi atau malah memunculkan menu utama.

Perbaikan:
1. Saat session kosong, input 1/2/3/4 tetap diproses sebagai pilihan menu utama.
2. Tombol Cek Status setelah Batal sekarang langsung masuk ke alur Cek Status.
3. Tombol Buat Aduan setelah Batal sekarang langsung masuk ke alur Buat Aduan.
4. Tombol Riwayat Aduan tetap berjalan seperti sebelumnya.
5. Semua update V10.9.16, V10.9.15, V10.9.14, V10.9.13, dan performance patch tetap dibawa.
