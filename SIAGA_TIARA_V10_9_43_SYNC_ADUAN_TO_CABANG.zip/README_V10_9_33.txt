SIAGA TIARA V10.9.33 - PENGUMUMAN AWAL SEBELUM MENU UTAMA

Update:
1. Bot bisa mengirim 2 pesan saat pelanggan membuka Menu Utama:
   - Pesan 1: Pengumuman Layanan
   - Pesan 2: Menu Utama / Pilih Layanan
2. Pengumuman diambil dari sheet baru: PENGUMUMAN.
3. Kolom sheet PENGUMUMAN:
   - STATUS
   - JUDUL
   - ISI
   - MULAI
   - SELESAI
   - URUTAN
4. Pengumuman hanya tampil jika STATUS berisi:
   - AKTIF / YA / ON / TRUE / 1
5. Jika kolom MULAI/SELESAI diisi, pengumuman hanya tampil dalam rentang tanggal tersebut.
6. Agar tidak spam, pengumuman yang sama dikirim maksimal 1x per nomor per 6 jam.
7. Pengumuman dikirim sebelum menu utama agar tombol "Pilih Layanan" tetap menjadi pesan terakhir dan mudah diklik.
8. Semua update V10.9.32 ke bawah tetap dibawa.

Cara pakai:
1. Deploy Code.gs terbaru.
2. Buka menu Spreadsheet: WhatsApp > Setup Sheet Pengumuman.
3. Isi sheet PENGUMUMAN.
4. Ubah STATUS menjadi AKTIF.
5. Coba kirim "menu" ke bot.
