SIAGA TIARA V10.9.41 - AUTO CABANG & WILAYAH

Perbaikan sesuai arahan:
1. Pada sheet CABANG_*, kolom Cabang otomatis mengikuti nama sheet.
   Contoh:
   - CABANG_PRY  -> Cabang Praya
   - CABANG_PRBD -> Cabang Praya Barat Daya

2. Kolom Wilayah/Kecamatan juga otomatis mengikuti cabang.
   Contoh:
   - CABANG_PRY  -> Praya
   - CABANG_PRBD -> Praya Barat Daya
   - CABANG_BTU  -> Batukliang Utara

3. Untuk input manual di sheet CABANG_*, cabang tidak perlu isi Cabang dan Wilayah lagi.

Minimal data manual sekarang:
- Nama Pelanggan
- Jenis Gangguan

Saran tetap isi:
- No Pelanggan
- No HP
- Keterangan Aduan
- Prioritas
- Unit/Petugas

Alur:
1. Cabang buka sheet CABANG_PRY / CABANG_PRBD / dst.
2. Isi Nama Pelanggan, No Pelanggan, No HP, Jenis Gangguan, Keterangan.
3. Sistem otomatis mengisi Cabang dan Wilayah.
4. Jika data minimal lengkap, sistem buat ID Aduan dan masuk ke ADUAN.

Catatan:
- Kalau Wilayah/Kecamatan sengaja diisi manual, sistem tidak menimpa.
- Auto-fill hanya bekerja jika baris memiliki input, supaya baris kosong tidak penuh tulisan default.
