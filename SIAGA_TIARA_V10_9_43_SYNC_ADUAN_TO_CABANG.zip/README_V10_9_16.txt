SIAGA TIARA V10.9.16 - NO PELANGGAN RINGKAS

Update:
1. Prompt input No Pelanggan dipersingkat.
2. Kalimat berikut dihapus dari prompt awal No Pelanggan:
   - Gunakan angka saja, minimal 5 digit dan maksimal 20 digit.
   - Contoh nomor pelanggan.
3. Validasi No Pelanggan tetap aktif di belakang layar.
4. Jika input salah, sistem tetap menolak dan memberi pesan validasi.
