SIAGA TIARA V10.9.21 - INFO & PEMBAYARAN

Update:
1. Menu utama nomor 4 diganti dari "Hubungi Admin/Petugas" menjadi "Info & Pembayaran".
2. List menu WhatsApp juga diganti:
   - Info Pembayaran
   - Deskripsi: Cara bayar dan kendala pembayaran
3. Menu Info & Pembayaran berisi:
   - Cara Bayar
   - Kendala Bayar
   - Menu Utama
4. Menu Kendala Bayar berisi panduan data yang perlu disiapkan pelanggan:
   - No Pelanggan
   - Nama pelanggan
   - Tanggal pembayaran
   - Kanal pembayaran
   - Nominal pembayaran
   - Bukti pembayaran jika ada
5. Hubungi Admin tetap tersedia dari menu Kendala Bayar.
6. Semua update V10.9.20 ke bawah tetap dibawa.

Catatan:
- Info & Pembayaran masih berupa informasi/panduan, belum cek tagihan otomatis.
- Kalau nanti data tagihan sudah tersedia, menu ini bisa dikembangkan menjadi Cek Tagihan Otomatis.
