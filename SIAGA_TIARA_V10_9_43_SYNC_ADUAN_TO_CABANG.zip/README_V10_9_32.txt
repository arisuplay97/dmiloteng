SIAGA TIARA V10.9.32 - FIX SAMBUNG KEMBALI

Masalah yang diperbaiki:
1. List "Sambung Kembali" tidak membuka detail.
   Penyebab: teks "Sambung Kembali" mengandung kata "kembali", sehingga sistem menganggapnya sebagai tombol Kembali.
2. List "Sambungan Pindah" tidak membuka detail.
   Penyebab: title yang dikirim provider bisa hanya "Sambungan Pindah", sedangkan kode sebelumnya hanya mengenali "sambungan pemindahan" / "pemindahan meter".

Perbaikan:
1. Normalizer sekarang membaca "Sambung Kembali" sebelum tombol umum "Kembali".
2. Ditambahkan alias "Sambungan Pindah" untuk menuju detail Sambungan Pemindahan Meter Air.
3. Global handler dan detail handler ikut ditambah alias agar lebih aman walaupun provider mengirim title saja.
4. Tombol "Kembali" dari detail tetap kembali ke menu Info Layanan.
5. Tombol "Menu Utama" tetap kembali ke List Menu Utama.

Tes:
- Info Layanan > Sambung Kembali = harus muncul detail Sambung Kembali.
- Info Layanan > Sambungan Pindah = harus muncul detail Sambungan Pemindahan Meter Air.
- Dari detail tekan Kembali = harus kembali ke Info Layanan.
- Dari detail tekan Menu Utama = harus kembali ke menu utama.
