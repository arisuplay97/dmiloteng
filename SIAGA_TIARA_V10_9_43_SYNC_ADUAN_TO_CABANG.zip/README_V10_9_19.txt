SIAGA TIARA V10.9.19 - FIX MENU LUAR JAM

Masalah yang diperbaiki:
1. Di luar jam kerja, tombol Menu Utama bisa membuat loop/duplikasi pesan menu luar jam.
2. Tombol Cek Status dan Riwayat Aduan perlu tetap aktif walaupun di luar jam kerja.
3. Pesan luar jam masih menyuruh pelanggan mengetik status/riwayat, padahal sudah ada tombol.

Perbaikan:
1. Tombol luar jam sekarang hanya:
   - Cek Status
   - Riwayat Aduan
   Tidak ada tombol Menu Utama di pesan luar jam agar tidak loop.
2. Tombol Cek Status tetap berjalan dan menampilkan permintaan ID aduan.
3. Tombol Riwayat Aduan tetap berjalan dan membuka daftar riwayat/tiket.
4. Pesan luar jam diarahkan memakai tombol, bukan ketik manual.
5. Jika pelanggan mengetik/menekan Menu Utama di luar jam kerja, sistem tetap menampilkan menu terbatas luar jam.
6. Semua update V10.9.18 ke bawah tetap dibawa.

Yang perlu dites:
- Di luar jam kerja klik Menu Utama: harus muncul menu terbatas dengan tombol Cek Status & Riwayat saja.
- Klik Cek Status: harus muncul permintaan ID Aduan.
- Klik Riwayat Aduan: harus tampil list/tombol Pilih Tiket.
- Klik Buat Aduan di luar jam kerja: harus ditolak dan tetap hanya menampilkan Cek Status & Riwayat.
