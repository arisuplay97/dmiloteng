SIAGA TIARA V10.9.42 - FIX INPUT MANUAL CABANG

Masalah yang diperbaiki:
1. Di sheet CABANG_* kolom Jenis Gangguan belum ada dropdown.
2. Baris manual belum otomatis membuat ID jika hanya ada No Pelanggan dan belum ada Nama Pelanggan.
3. Jika Jenis Gangguan kosong tapi Keterangan berisi kata seperti "mati", sistem belum menebak jenis gangguan.
4. Refresh dropdown cabang belum sekaligus merapikan Cabang/Wilayah pada baris lama.

Perbaikan:
1. Dropdown ditambahkan pada kolom:
   - Jenis Gangguan
   - Prioritas
   - Status
   - Unit/Petugas

2. Minimal input manual di sheet CABANG_* sekarang:
   - Nama Pelanggan ATAU No Pelanggan
   - Jenis Gangguan

3. Kalau Jenis Gangguan kosong, sistem mencoba menebak dari Keterangan:
   - "mati" -> Air Mati
   - "bocor/pipa" -> Pipa Bocor
   - "meter" -> Meter Bermasalah
   - "keruh" -> Air Keruh
   - dst.

4. Cabang/Wilayah tetap otomatis mengikuti nama sheet:
   - CABANG_PRY -> Cabang Praya / Praya
   - CABANG_PRBD -> Cabang Praya Barat Daya / Praya Barat Daya

Langkah setelah deploy:
1. Deploy Code.gs dengan New version.
2. Reload spreadsheet.
3. Klik:
   SIAGA TIARA > Cabang > Refresh Dropdown Status/Unit Cabang

   Walaupun nama menunya Status/Unit, sekarang menu itu juga memasang dropdown Jenis Gangguan dan merapikan Cabang/Wilayah.

4. Kalau data yang sudah telanjur diisi belum muncul ID, klik:
   SIAGA TIARA > Cabang > Sinkron Manual Sheet Cabang ke ADUAN

Catatan:
- ID otomatis muncul kalau data minimal sudah lengkap.
- Kalau cuma isi No Pelanggan tanpa Jenis Gangguan/Keterangan yang bisa ditebak, sistem belum membuat ID agar tidak membuat aduan palsu.
- Jika ingin paling aman, isi Jenis Gangguan dari dropdown.
