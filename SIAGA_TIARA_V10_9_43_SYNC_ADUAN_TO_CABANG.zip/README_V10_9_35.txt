SIAGA TIARA V10.9.35 - AUTO NONAKTIF PENGUMUMAN

Update:
1. Pengumuman yang memiliki tanggal SELESAI dan tanggalnya sudah lewat bisa otomatis berubah menjadi NONAKTIF.
2. Setting ada di CONFIG:

   PENGUMUMAN_AUTO_NONAKTIF_EXPIRED: 'YA',

3. Jika 'YA':
   - Setelah tanggal SELESAI lewat, pengumuman tidak tampil.
   - STATUS di sheet PENGUMUMAN otomatis diubah menjadi NONAKTIF.

4. Jika 'TIDAK':
   - Setelah tanggal SELESAI lewat, pengumuman tetap tidak tampil.
   - Tapi STATUS di sheet tetap AKTIF.

5. Contoh:
   STATUS: AKTIF
   MULAI: 2026-05-13
   SELESAI: 2026-05-13

   Maka pengumuman tampil sampai 13 Mei 2026 pukul 23:59.
   Mulai 14 Mei 2026, pengumuman tidak tampil dan STATUS berubah menjadi NONAKTIF.

6. Semua update V10.9.34 ke bawah tetap dibawa.
