SIAGA TIARA V10.9.40 - ONE SHEET CABANG

Update besar:
1. Sheet INPUT_* tidak dipakai lagi.
2. Manual input cabang sekarang langsung dilakukan di sheet CABANG_*.
3. Jadi setiap cabang cukup punya 1 sheet:
   - CABANG_PRY
   - CABANG_PRBD
   - CABANG_PJT
   - dst.

Fungsi sheet CABANG_* sekarang:
1. Melihat aduan yang masuk otomatis dari WhatsApp.
2. Update Status / Unit / Prioritas / Catatan.
3. Input manual aduan baru dari cabang.

Cara input manual di CABANG_*:
1. Buka sheet cabang, misalnya CABANG_PRBD.
2. Turun ke baris kosong.
3. Isi minimal:
   - Wilayah/Kecamatan
   - Nama Pelanggan
   - Jenis Gangguan
4. Sebaiknya isi juga:
   - No HP
   - No Pelanggan
   - Prioritas
   - Unit/Petugas
   - Keterangan Aduan
   - Lokasi Detail
5. Jika data minimal sudah lengkap, sistem akan membuat ID Aduan otomatis dan memasukkan data ke ADUAN.
6. Jika belum otomatis, jalankan:
   Cabang > Sinkron Manual Sheet Cabang ke ADUAN

Kolom ID Aduan:
- Kosong = dianggap input manual baru.
- Sudah ada ID = dianggap aduan resmi yang sudah masuk sistem.

Update status:
- Kalau status/unit/catatan di CABANG_* diubah, sheet ADUAN ikut berubah.
- Kalau status berubah, sistem tetap mencoba kirim notifikasi pelanggan jika masih dalam window 24 jam.

Sheet INPUT lama:
- Tidak dibuat lagi oleh setup.
- Bisa dihapus lewat menu:
  Cabang > Hapus Sheet INPUT Lama

Auto sync:
- Tetap bisa dipakai.
- Menu:
  Lanjutan > Aktifkan Sinkron Otomatis Sheet Cabang
- Interval tetap diatur dari:
  SYNC_INPUT_INTERVAL_MINUTES: 5,

Catatan:
- LOG_INPUT_CABANG tetap dipakai sebagai log manual cabang, meskipun nama sheet log masih lama.
- Semua update V10.9.39 ke bawah tetap dibawa.
