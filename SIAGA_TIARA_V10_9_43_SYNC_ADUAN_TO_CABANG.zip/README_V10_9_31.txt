SIAGA TIARA V10.9.31 - FIX INFO BUTTONS

Masalah yang diperbaiki:
1. Tombol/list "Cara Bayar" dan "Kendala Bayar" tidak membuka detail.
   Penyebab: teks list yang dikirim provider mengandung kata "pembayaran",
   sehingga terbaca sebagai menu induk Info Pembayaran.
2. Tombol "Kembali" pada detail Info Layanan kadang kembali ke Menu Utama.
   Penyebab: provider kadang hanya mengirim title "Kembali", bukan id PAY_INFO.

Perbaikan:
1. Normalizer menu diperbaiki:
   - Cara Bayar dibaca sebagai detail "cara bayar"
   - Kendala Bayar dibaca sebagai detail "kendala pembayaran"
   - Baru setelah itu masuk ke menu induk Info Layanan
2. Setiap halaman detail Info Layanan menyimpan session INFO_LAYANAN_DETAIL.
3. Tombol "Kembali" dari halaman detail akan kembali ke List Info Layanan.
4. Tombol "Menu Utama" tetap kembali ke menu utama/list utama.
5. Semua detail lain ikut dicek:
   - Air Tangki
   - Balik Nama
   - Pindah Meter Air
   - Sambung Kembali
   - Sambungan Pemindahan Meter Air

Tes setelah deploy:
- Buka Info Layanan
- Pilih Cara Bayar -> harus tampil detail Cara Bayar
- Tekan Kembali -> harus balik ke Info Layanan
- Pilih Kendala Bayar -> harus tampil detail Kendala Bayar
- Tekan Kembali -> harus balik ke Info Layanan
- Pilih Air Tangki -> detail
- Tekan Kembali -> balik ke Info Layanan, bukan Menu Utama
- Tekan Menu Utama -> balik ke list menu utama
