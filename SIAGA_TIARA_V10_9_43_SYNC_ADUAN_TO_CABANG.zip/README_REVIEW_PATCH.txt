SIAGA TIARA V10.9.12 - REVIEW PERFORMANCE PATCH

Hasil review dari V10.9.11:
1. V10.9.11 memakai getRuntimeProp_() tapi fungsi itu belum ada.
2. V10.9.11 memakai _interactiveMenuFlag tapi variabel globalnya belum ada.
3. Cek batas aduan aktif masih terjadi di setiap langkah input aduan.
4. getActiveAduansByPhone_ masih membaca 20 kolom, padahal cek aktif cukup sampai kolom STATUS.

Perbaikan V10.9.12:
1. Menambahkan runtime property cache: getRuntimeProp_(), clearRuntimePropCache_(), _runtimePropsCache, _interactiveMenuFlag.
2. Cek batas aduan aktif hanya saat mulai Buat Aduan dan saat final sebelum simpan.
3. Fungsi cek aduan aktif dibuat lebih ringan: baca kolom penting saja dan scan dari data terbaru ke data lama.
4. Nama file dibuat Code.gs agar lebih mudah dipakai di Apps Script.

Catatan:
- Ini patch review untuk Code.gs. Tetap test dulu di deployment Apps Script cadangan sebelum mengganti produksi.
