SIAGA TIARA V10.9.36 - SYNC INTERVAL CONFIG

Update:
1. Sinkron otomatis INPUT cabang sekarang default setiap 5 menit.
2. Jeda sync bisa diganti cukup dari CONFIG:

   SYNC_INPUT_INTERVAL_MINUTES: 5,

3. Angka yang aman:
   - 1  = setiap 1 menit
   - 5  = setiap 5 menit
   - 10 = setiap 10 menit
   - 15 = setiap 15 menit
   - 30 = setiap 30 menit

4. Jika diisi angka lain, sistem akan memakai pilihan terdekat ke atas.
   Contoh:
   - isi 2  -> dipakai 5 menit
   - isi 12 -> dipakai 15 menit
   - isi 60 -> dipakai 30 menit

5. Setelah deploy, aktifkan ulang trigger:
   Menu Spreadsheet > SIAGA TIARA > Lanjutan > Aktifkan Sinkron Otomatis

   Fungsi itu otomatis menghapus trigger sync lama lalu membuat trigger baru sesuai CONFIG.

6. Semua update V10.9.35 ke bawah tetap dibawa.
