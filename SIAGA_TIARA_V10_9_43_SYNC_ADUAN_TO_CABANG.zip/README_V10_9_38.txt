SIAGA TIARA V10.9.38 - DROPDOWN STATUS/UNIT SHEET CABANG

Masalah:
- Sheet CABANG_PRY, CABANG_PTE, CABANG_PRB, dan cabang lain belum punya dropdown/tombol untuk Status dan Unit/Petugas.
- Cabang perlu bisa mengubah status/unit dari sheet cabangnya masing-masing.

Perbaikan:
1. Ditambahkan dropdown pada sheet CABANG_*:
   - Prioritas
   - Status
   - Unit/Petugas

2. Ditambahkan menu:
   Cabang > Refresh Dropdown Status/Unit Cabang

3. Menu "Setup Sheet Aduan Cabang" sekarang juga memasang dropdown otomatis.

4. Jika cabang mengubah Status/Unit/Catatan/Prioritas di sheet CABANG_*:
   - Data utama di sheet ADUAN ikut diperbarui.
   - Jika Status berubah, sistem mencoba kirim notifikasi status ke pelanggan jika masih dalam window 24 jam.
   - Jika window 24 jam sudah lewat, hanya dicatat di LOG_NOTIF_STATUS.

Cara pakai setelah deploy:
1. Deploy Code.gs terbaru dengan Manage deployments > Edit > New version.
2. Reload spreadsheet.
3. Klik menu:
   Cabang > Refresh Dropdown Status/Unit Cabang
4. Buka sheet CABANG_PRY atau cabang lain.
5. Kolom Status dan Unit/Petugas sudah bisa dipilih dari dropdown.

Catatan:
- Google Sheets menyebutnya dropdown, bukan tombol WA.
- Dropdown muncul saat sel di kolom Status/Unit diklik.
- Data lama tidak dihapus.
